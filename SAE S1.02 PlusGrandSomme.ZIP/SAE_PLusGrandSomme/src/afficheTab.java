class SimplesTableau {
	void principal() {
		System.out.println("ça marche");
		int [] tab = {2,3,5,7,8,9,10};  
	}
	
	void afficheTab(int [] tab, int nbElem) {
		System.out.print("Le tableau { ");
		for ( int k = 0; k < nbElem; k++) {
			if ( k >= 0 && k != tab.length - 1){
				System.out.print(tab[k]+", ");
			} else {
				System.out.print(tab[k]);
			}			
		}
		System.out.println(" }");
	}
}
